<!DOCTYPE HTML>
<html>
    <head>
        <title> Date and Time </title>
    </head>
    <body>
        <h3> Time </h3>
        <?php
            date_default_timezone_set("asia/jakarta");
            echo date("h:i:sa");
        ?>
    </body>
</html>
