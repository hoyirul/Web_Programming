<!DOCTYPE HTML>
<html>
    <head>
    <title>Fungsi</title>
    </head>
    <body>
        <h2> Fungsi </h2>
        <?php
            function writeMsg(){
                echo "Hello World";
            }

            writeMsg();
        ?>
    </body>
</html>

