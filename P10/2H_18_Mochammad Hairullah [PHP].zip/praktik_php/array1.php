<!DOCTYPE HTML>
<html>
    <head>
    <title>Indexed Array</title>
    </haed>
    <body>
    <h2> Indexed Array </h2>
        <?php
            $buah = array("Mangga", "Apel", "Jeruk");

            echo "Buah " . $buah[0]. " dan ". $buah[1]. " rasanya manis sekali";
        ?>
    </body>
</html>
