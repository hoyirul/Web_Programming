<!DOCTYPE HTML>
<html>
    <head>
        <title>KONSTANTA PHP</title>
    </head>
    <body>
        <?php
            $var = "ini adalah contoh variabel";
            echo $var;
            echo "<br><br>";
            define('KONSTANTA', "ini adalah contoh konstanta");
            echo KONSTANTA;
            echo "<br>";
            echo KONSTANTA;
        ?>
    </body>
</html>