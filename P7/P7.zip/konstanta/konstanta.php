<!DOCTYPE HTML>
<html>
    <head>
    </head>
    <body>
        <?php
            $var = "ini adalah contoh variabel";
            echo $var;
            echo "<br><br>";
            define("konstanta", "ini adalah contoh konstanta", true);
            echo konstanta;
            echo "<br>";
            echo KONSTANTA;
        ?>
    </body>
</html>