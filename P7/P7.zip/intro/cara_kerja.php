<!DOCTYPE html>
<html>
    <head>
        <title>Cara Kerja</title>
    </head>
    <body>
        <p> kalimat dengan menggunakan HTML </p>
        <?php
            echo "kalimat degan menggunakan PHP";
        ?>
    </body>
</html>