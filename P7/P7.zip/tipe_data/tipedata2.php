<!DOCTYPE html>
<html>
    <head>
        <title>Konversi Tipe Data</title>
    </head>
    <body>
        <h2> Konversi Tipe Data</h2>
        <?php
            $a = 10.5;
            $b = "9 kucing";
            echo $a;
            echo "<br>".(integer) $a;
            echo "<br>". $b;
            echo "<br>".(integer)$b;
        ?>
    </body>
</html>