<!DOCTYPE html>
<html>
    <head>
        <title>Tipe Data PHP</title>
    </head>
    <body>
        <?php
            $a = "Hello World!";
            $b = 99;
            $c = 8.8;
            $d = NULL;
            var_dump ($a,$b,$c,$d);
        ?>
    </body>
</html>