<!DOCTYPE html>
<html>
    <head>
    <title>Variabel PHP</title>
    </head>
    <body>
        <?php
        $hello = "Hello World!";
        echo $hello;
        ?>
    </body>
</html>

