<!DOCTYPE html>
    <html>
    <head>
        <title>Operator PHP</title>
    </head>
    <body>
        <?php 
            // soal 12
            //$nomor = 1;
            //while ($nomor <= 5) {
            //    echo $nomor++;
            //}

            //soal 13
            $nomor = 1;
            while ($nomor <= 5) {
                echo ++$nomor;
            }
        ?>
    </body>
</html>