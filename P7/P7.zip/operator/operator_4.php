<!DOCTYPE html>
<html>
    <head>
        <title>Operator PHP</title>
    </head>
    <body>
        <?php
            // soal 10
            $x = 4;
            $x += 3;
            echo "hasil operasi tersebut adalah = $x";
            
            // soal 11
            echo "<h3> Soal No 11 </h3>";
            echo "<h3> Menggunakan operasi -= </h3>";
            $x = 4;
            $x -= 3;
            echo "hasil operasi tersebut adalah = $x";
            echo "<br><br>";

            echo "<h3> Menggunakan operasi *= </h3>";
            $x = 4;
            $x *= 3;
            echo "hasil operasi tersebut adalah = $x";
            echo "<br><br>";

            echo "<h3> Menggunakan operasi /= </h3>";
            $x = 4;
            $x /= 3;
            echo "hasil operasi tersebut adalah = $x";
            echo "<br><br>";

            echo "<h3> Menggunakan operasi %= </h3>";
            $x = 4;
            $x %= 3;
            echo "hasil operasi tersebut adalah = $x";
            echo "<br><br>";

            echo "<h3> Menggunakan operasi .= </h3>";
            $x = 4;
            $x .= 3;
            echo "hasil operasi tersebut adalah = $x";
        ?>
    </body>
</html>