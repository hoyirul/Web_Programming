<!DOCTYPE html>
<html>
    <head>
        <title>Operator PHP</title>
    </head>
    <body>
        <?php 
            $a = 5;
            $b = 2;
            echo "hasil penambahan $a dan $b adalah "; echo $a + $b;
            echo "<br> hasil pengurangan $a dan $b adalah "; echo $a - $b;
            echo "<br> hasil perkalian $a dan $b adalah "; echo $a * $b;
            echo "<br> hasil pembagian $a dan $b adalah "; echo $a / $b;
            echo "<br> hasil sisa pembagian $a dan $b adalah "; echo $a % $b;
        ?>
    </body>
</html>