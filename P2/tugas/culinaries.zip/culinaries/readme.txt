Nama : Mochammad Hairullah
NIM  : 2041720074

Langkah Install

1. Download culinaries.zip 
2. Extract culinaries.zip ke {path}/xampp/htdocs/
3. Jalankan xampp control
4. Akses localhost/culinaries/ melalui web browser
5. Selesai